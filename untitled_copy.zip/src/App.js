import Spline from '@splinetool/react-spline';

export default function App() {
  return (
    <Spline scene="https://prod.spline.design/ZgCfsWXCm1E9Nqf2/scene.splinecode" />
  );
}
